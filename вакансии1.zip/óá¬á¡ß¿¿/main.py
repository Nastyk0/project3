from os import abort
from flask import Flask, render_template, request
from werkzeug.utils import redirect
from forms.LoginForm import LoginForm
from data import db_session
from data.users import User
from data.vacancies import Vacancies
from data.resumes import Resumes
from forms.vacancies import VacanciesForm
from forms.resumes import ResumesForm
import sys
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from forms.user import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route("/")
def index():
    db_sess = db_session.create_session()
    vacancies = db_sess.query(Vacancies).all()
    resumes = db_sess.query(Resumes).all()
    user = db_sess.query(User).all()
    return render_template("index.html", vacancies=vacancies, resumes=resumes, user=user)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='RegisterForm',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='RegisterForm',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            surname=form.surname.data,
            name=form.name.data,
            email=form.email.data,
            position=form.position.data,
            speciality=form.speciality.data,
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/vacancies', methods=['GET', 'POST'])
def add_vacancies():
    form = VacanciesForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        vacancies = Vacancies(
            company_name=form.company_name.data,
            job=form.job.data,
            experience=form.experience.data,
            salary=form.salary.data,
            town=form.town.data,
            hour_work=form.hour_work.data,
            duties=form.duties.data
        )
        db_sess.add(vacancies)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('vacancies.html', title='Add vacancies', form=form)


@app.route('/edit_vacancies', methods=['GET', 'POST'])
@login_required
def edit_vacancies():
    form = VacanciesForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        vacancies = db_sess.query(Vacancies).first()
        if vacancies:
            form.company_name.data = vacancies.company_name,
            form.job.data = vacancies.job,
            form.experience.data = vacancies.experience,
            form.salary.data = vacancies.salary,
            form.town.data = vacancies.town,
            form.hour_work.data = vacancies.hour_work,
            form.duties.data = vacancies.duties
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        vacancies = db_sess.query(Vacancies).first()
        if vacancies:
            form.company_name.data = vacancies.company_name,
            form.job.data = vacancies.job,
            form.experience.data = vacancies.experience,
            form.salary.data = vacancies.salary,
            form.town.data = vacancies.town,
            form.hour_work.data = vacancies.hour_work,
            form.duties.data = vacancies.duties
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('vacancies.html',
                           title='Edit vacancies',
                           form=form
                           )


@app.route('/vacancies_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def vacancies_delete(id):
    db_sess = db_session.create_session()
    vacancies = db_sess.query(Vacancies).filter(Vacancies.id == id,
                                      ).first()
    if vacancies:
        db_sess.delete(vacancies)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/resumes', methods=['GET', 'POST'])
def add_resumes():
    form = ResumesForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        resumes = Resumes(
            name=form.name.data,
            job=form.job.data,
            experience=form.experience.data,
            salary=form.salary.data,
            town=form.town.data,
            hour_work=form.hour_work.data,
            skills=form.skills.data
        )
        db_sess.add(resumes)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('resumes.html', title='Add resumes', form=form)


@app.route('/edit_resumes', methods=['GET', 'POST'])
@login_required
def edit_resumes():
    form = ResumesForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        resumes = db_sess.query(Resumes).first()
        if resumes:
            form.name.data = resumes.name,
            form.job.data = resumes.job,
            form.experience.data = resumes.experience,
            form.salary.data = resumes.salary,
            form.town.data = resumes.town,
            form.hour_work.data = resumes.hour_work,
            form.skills.data = resumes.skills
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        resumes = db_sess.query().first()
        if resumes:
            form.name.data = resumes.name,
            form.job.data = resumes.job,
            form.experience.data = resumes.experience,
            form.salary.data = resumes.salary,
            form.town.data = resumes.town,
            form.hour_work.data = resumes.hour_work,
            form.skills.data = resumes.skills
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('resumes.html',
                           title='Edit resumes',
                           form=form
                           )


@app.route('/resumes_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def resumes_delete(id):
    db_sess = db_session.create_session()
    resumes = db_sess.query(Resumes).filter(Resumes.id == id,
                                      ).first()
    if resumes:
        db_sess.delete(resumes)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


if __name__ == '__main__':
    db_session.global_init("db/works.db")
    app.run(port=8080, host='127.0.0.1')