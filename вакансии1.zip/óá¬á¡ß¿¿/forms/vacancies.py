from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField
from wtforms.validators import DataRequired


class VacanciesForm(FlaskForm):
    company_name = StringField('Company name', validators=[DataRequired()])
    job = StringField('Job', validators=[DataRequired()])
    experience = StringField('Experience', validators=[DataRequired()])
    salary = StringField('Salary', validators=[DataRequired()])
    town = StringField('Town', validators=[DataRequired()])
    hour_work = StringField('Hour work', validators=[DataRequired()])
    duties = StringField('Duties', validators=[DataRequired()])
    submit = SubmitField('Save')