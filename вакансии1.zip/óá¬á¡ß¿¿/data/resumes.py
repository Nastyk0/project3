import datetime
import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Resumes(SqlAlchemyBase):
    __tablename__ = 'resumes'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String)
    job = sqlalchemy.Column(sqlalchemy.String)
    experience = sqlalchemy.Column(sqlalchemy.Integer)
    salary = sqlalchemy.Column(sqlalchemy.String)
    town = sqlalchemy.Column(sqlalchemy.String)
    hour_work = sqlalchemy.Column(sqlalchemy.String)
    skills = sqlalchemy.Column(sqlalchemy.String)