import datetime
import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Respond(SqlAlchemyBase):
    __tablename__ = 'respond'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    your_name = sqlalchemy.Column(sqlalchemy.String)
    name = sqlalchemy.Column(sqlalchemy.String)
    mes = sqlalchemy.Column(sqlalchemy.String)