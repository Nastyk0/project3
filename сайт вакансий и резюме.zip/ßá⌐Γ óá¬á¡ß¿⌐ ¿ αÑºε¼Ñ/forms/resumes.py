from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField
from wtforms.validators import DataRequired


class ResumesForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    job = StringField('Job', validators=[DataRequired()])
    experience = StringField('Experience', validators=[DataRequired()])
    salary = StringField('Salary', validators=[DataRequired()])
    town = StringField('Town', validators=[DataRequired()])
    hour_work = StringField('Hour work', validators=[DataRequired()])
    skills = StringField('Skills', validators=[DataRequired()])
    submit = SubmitField('Save')