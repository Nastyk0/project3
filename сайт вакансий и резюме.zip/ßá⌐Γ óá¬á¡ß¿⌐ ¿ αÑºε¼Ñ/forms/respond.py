from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


class RespondForm(FlaskForm):
    your_name = StringField('Ваше имя/название компании', validators=[DataRequired()])
    name = StringField('Кому хотите написать? (Имя/название компании)', validators=[DataRequired()])
    mes = StringField('Ваше сообщение', validators=[DataRequired()])
    submit = SubmitField('Отправить отклик')