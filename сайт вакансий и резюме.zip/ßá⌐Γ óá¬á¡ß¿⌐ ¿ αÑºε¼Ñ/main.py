from os import abort
from flask import Flask, render_template
from werkzeug.utils import redirect
from forms.LoginForm import LoginForm
from data import db_session
from data.users import User
from data.vacancies import Vacancies
from data.resumes import Resumes
from data.respond import Respond
from forms.vacancies import VacanciesForm
from forms.resumes import ResumesForm
from forms.respond import RespondForm
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from forms.user import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route("/")
def index():
    db_sess = db_session.create_session()
    vacancies = db_sess.query(Vacancies).all()
    resumes = db_sess.query(Resumes).all()
    user = db_sess.query(User).all()
    return render_template("index.html", vacancies=vacancies, resumes=resumes, user=user)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='RegisterForm',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='RegisterForm',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            surname=form.surname.data,
            name=form.name.data,
            email=form.email.data,
            position=form.position.data,
            speciality=form.speciality.data,
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/vacancies', methods=['GET', 'POST'])
def add_vacancies():
    form = VacanciesForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        vacancies = Vacancies(
            company_name=form.company_name.data,
            job=form.job.data,
            experience=form.experience.data,
            salary=form.salary.data,
            town=form.town.data,
            hour_work=form.hour_work.data,
            duties=form.duties.data
        )
        db_sess.add(vacancies)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('vacancies.html', title='Add vacancies', form=form)


@app.route('/view_p', methods=['GET', 'POST'])
def otklik1():
    db_sess = db_session.create_session()
    respond = db_sess.query(Respond).all()
    return render_template('view_user.html', title='Просмотр откликов', respond=respond)


@app.route('/view_r', methods=['GET', 'POST'])
def otklik():
    db_sess = db_session.create_session()
    respond = db_sess.query(Respond).all()
    return render_template('view_company.html', title='Просмотр откликов', respond=respond)


@app.route('/respond_resumes', methods=['GET', 'POST'])
def otklik2():
    form = RespondForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        respond = Respond(
            your_name=form.your_name.data,
            name=form.name.data,
            mes=form.mes.data
        )
        db_sess.add(respond)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('respond_resumes.html', title='Respond', form=form)


@app.route('/respond_vacancies', methods=['GET', 'POST'])
def otklik3():
    form = RespondForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        respond = Respond(
            your_name=form.your_name.data,
            name=form.name.data,
            mes=form.mes.data
        )
        db_sess.add(respond)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('respond_resumes.html', title='Respond', form=form)


@app.route('/vacancies_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def vacancies_delete(id):
    db_sess = db_session.create_session()
    vacancies = db_sess.query(Vacancies).filter(Vacancies.id == id,
                                      ).first()
    if vacancies:
        db_sess.delete(vacancies)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/resumes', methods=['GET', 'POST'])
def add_resumes():
    form = ResumesForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        resumes = Resumes(
            name=form.name.data,
            job=form.job.data,
            experience=form.experience.data,
            salary=form.salary.data,
            town=form.town.data,
            hour_work=form.hour_work.data,
            skills=form.skills.data
        )
        db_sess.add(resumes)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('resumes.html', title='Add resumes', form=form)


@app.route('/resumes_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def resumes_delete(id):
    db_sess = db_session.create_session()
    resumes = db_sess.query(Resumes).filter(Resumes.id == id,
                                      ).first()
    if resumes:
        db_sess.delete(resumes)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/view_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def view_delete(id):
    db_sess = db_session.create_session()
    respond = db_sess.query(Respond).filter(Respond.id == id,
                                      ).first()
    if respond:
        db_sess.delete(respond)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


if __name__ == '__main__':
    db_session.global_init("db/works.db")
    app.run(port=8080, host='127.0.0.1')