import datetime
import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Vacancies(SqlAlchemyBase):
    __tablename__ = 'vacancies'

    job = sqlalchemy.Column(sqlalchemy.String)
    experience = sqlalchemy.Column(sqlalchemy.Integer)
    salary = sqlalchemy.Column(sqlalchemy.String)
    town = sqlalchemy.Column(sqlalchemy.String)
    hour_work = sqlalchemy.Column(sqlalchemy.String)
    duties = sqlalchemy.Column(sqlalchemy.String)